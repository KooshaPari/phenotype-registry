# CLAUDE.md — phenotype-bus

## Project Overview

**Name**: phenotype-bus
**Purpose**: Rust event bus for Phenotype services
**Language**: Rust
**Status**: Active

## Development

### Build
```bash
cargo build
```

### Test
```bash
cargo test --workspace
```

### Lint & Format
```bash
cargo clippy --workspace
```

## Quality Gates

- All tests must pass
- All lints must pass
- No suppressions without justification

## Governance References

- **Parent governance**: `/Users/kooshapari/CodeProjects/Phenotype/repos/CLAUDE.md`
- **Global governance**: `/Users/kooshapari/.claude/CLAUDE.md`
- **Local agents**: See `AGENTS.md`
