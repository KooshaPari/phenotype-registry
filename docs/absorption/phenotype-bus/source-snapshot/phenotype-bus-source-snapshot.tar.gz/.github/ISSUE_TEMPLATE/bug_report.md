---
name: Bug Report
about: Report a defect in phenotype-bus
title: "[BUG] "
labels: ["bug", "triage"]
assignees: []
---

## Describe the bug

<!-- Clear, concise description of the bug -->

## Reproduction steps

1.
2.
3.

## Expected behavior

<!-- What did you expect to happen? -->

## Actual behavior

<!-- What actually happened? Include stack traces if applicable. -->

## Environment

- OS:
- Rust version (`rustc --version`):
- Crate version:
- Feature flags enabled:

## Additional context

<!-- Links to related issues, PRs, or specs. Screenshots / traces if helpful. -->

## Acceptance criteria

- [ ] Repro confirmed by maintainer
- [ ] Fix proposed or PR opened
- [ ] Regression test added