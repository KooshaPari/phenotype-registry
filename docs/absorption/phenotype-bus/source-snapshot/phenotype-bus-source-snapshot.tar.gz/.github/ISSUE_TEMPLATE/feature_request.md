---
name: Feature Request
about: Suggest a new feature for phenotype-bus
title: "[FEATURE] "
labels: ["enhancement", "triage"]
assignees: []
---

## Problem

<!-- What user need is unmet? What problem are you trying to solve? -->

## Proposed solution

<!-- Describe the API or behavior you'd like to see. -->

## Alternatives considered

<!-- What other approaches did you consider, and why this one? -->

## Acceptance criteria

<!-- How will we know this is done? -->

- [ ]
- [ ]

## Out of scope

<!-- What this proposal does NOT include. -->

## Related

<!-- Links to related issues, PRs, or specs (e.g. FUNCTIONAL_REQUIREMENTS.md). -->