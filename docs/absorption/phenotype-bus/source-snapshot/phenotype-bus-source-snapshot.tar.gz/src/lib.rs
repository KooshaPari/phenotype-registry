//! Typed async pub/sub for Phenotype collections.
//!
//! The Wave-1 type set (`Bus`, `InMemoryBus`, `Event`, `BusError`, `Ack`,
//! `Subscription`, `EventBus`, `EventId`, `EventTimestamp`) has been
//! superseded by the Wave-2 module in [`events`].  Consumers should
//! migrate to the Wave-2 API:
//!
//! ```ignore
//! use phenotype_bus::events::{Event, EventBus, InMemoryBus};
//! ```
//!
//! The crate is **deprecated** as of 2026-06-18 and the
//! in-memory bus pattern has been lifted to
//! [`phenoEvents`](https://github.com/KooshaPari/phenoEvents) (PR #9).
//! This crate will be archived on 2026-06-25.
//!
//! # Configuration
//!
//! See the [`config`] module for environment-variable-driven configuration.

pub mod config;
pub mod events;
pub mod observability;

pub use config::Config;

/// Crate version, sourced from `Cargo.toml` at compile time.
pub const VERSION: &str = env!("CARGO_PKG_VERSION");

/// Crate name, sourced from `Cargo.toml` at compile time.
pub const NAME: &str = env!("CARGO_PKG_NAME");

/// Return the crate version as a static string.
///
/// This is a publish-ready helper for downstream consumers that want to
/// pin a known-good `phenotype-bus` version in their lockfiles.
pub fn version() -> &'static str {
    VERSION
}

/// Return the crate name as a static string.
pub fn name() -> &'static str {
    NAME
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::events::{
        Event, EventBus, HandlerError, IdempotentHandler, InMemoryBus, RetryPolicy,
    };
    use crate::observability::init_tracing;
    use chrono::{DateTime, Utc};
    use std::sync::Arc;
    use std::time::Duration;
    use uuid::Uuid;

    #[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
    struct Wave2Sample {
        id: Uuid,
        kind: String,
        source: String,
        ts: DateTime<Utc>,
        message: String,
    }

    impl Wave2Sample {
        fn new(kind: &str, message: &str) -> Self {
            Self {
                id: Uuid::new_v4(),
                kind: kind.to_string(),
                source: "phenotype-bus".to_string(),
                ts: Utc::now(),
                message: message.to_string(),
            }
        }
    }

    impl Event for Wave2Sample {
        fn id(&self) -> Uuid {
            self.id
        }
        fn kind(&self) -> &str {
            &self.kind
        }
        fn source(&self) -> &str {
            &self.source
        }
        fn ts(&self) -> DateTime<Utc> {
            self.ts
        }
    }

    /// Compile-time check that `EventBus` is object-safe enough to take a
    /// `&dyn Event` (this is the surface every Wave-2 test exercises).
    fn _eventbus_trait_is_in_scope() {
        fn assert_eventbus<T: EventBus + ?Sized>() {}
        assert_eventbus::<InMemoryBus>();
    }

    #[tokio::test]
    async fn publish_subscribe_wave2() {
        init_tracing();
        let bus = InMemoryBus::new();
        let received: Arc<std::sync::Mutex<Vec<Uuid>>> =
            Arc::new(std::sync::Mutex::new(Vec::new()));
        let r = received.clone();
        let _sub = bus
            .subscribe(move |event: &dyn Event| {
                let r = r.clone();
                let id = event.id();
                async move {
                    r.lock().unwrap().push(id);
                    Ok(())
                }
            })
            .await;

        let evt = Wave2Sample::new("user.created", "alice");
        let ack = bus.publish(&evt).await.expect("publish ok");
        assert_eq!(ack.event_id, evt.id);
        assert_eq!(ack.kind, "user.created");
        assert_eq!(ack.delivered_to, 1);

        let ids = received.lock().unwrap();
        assert_eq!(ids.len(), 1);
        assert_eq!(ids[0], evt.id);
    }

    #[tokio::test]
    async fn at_least_once_retry_wave2() {
        let bus = InMemoryBus::with_retry(RetryPolicy {
            max_attempts: 4,
            backoff: Duration::from_millis(0),
        });
        let attempts = Arc::new(tokio::sync::Mutex::new(0usize));
        let a = attempts.clone();
        let _sub = bus
            .subscribe(move |_event: &dyn Event| {
                let a = a.clone();
                async move {
                    let mut n = a.lock().await;
                    *n += 1;
                    if *n < 3 {
                        Err(HandlerError::Transient("flake".into()))
                    } else {
                        Ok(())
                    }
                }
            })
            .await;

        let evt = Wave2Sample::new("retry.kind", "x");
        let ack = bus.publish(&evt).await.expect("publish ok after retries");
        assert_eq!(ack.delivered_to, 1);
        assert_eq!(*attempts.lock().await, 3);
    }

    #[tokio::test]
    async fn idempotency_dedup_wave2() {
        let inner_calls = Arc::new(tokio::sync::Mutex::new(0usize));
        let inner_seen = Arc::new(tokio::sync::Mutex::new(Vec::<Uuid>::new()));
        let calls = inner_calls.clone();
        let seen = inner_seen.clone();
        let handler = IdempotentHandler::new(move |event: &dyn Event| {
            let calls = calls.clone();
            let seen = seen.clone();
            let id = event.id();
            async move {
                *calls.lock().await += 1;
                seen.lock().await.push(id);
                Ok(())
            }
        });
        let bus = InMemoryBus::new();
        let _sub = bus.subscribe(handler).await;

        // Publish the same id 3 times; the inner handler should only fire once.
        let evt = Wave2Sample::new("dedup.kind", "once");
        for _ in 0..3 {
            let ack = bus.publish(&evt).await.expect("publish ok");
            assert_eq!(ack.delivered_to, 1);
        }
        assert_eq!(*inner_calls.lock().await, 1);
        assert_eq!(inner_seen.lock().await.len(), 1);
    }

    #[tokio::test]
    async fn multiple_handlers_wave2() {
        let bus = InMemoryBus::new();
        let a = Arc::new(tokio::sync::Mutex::new(0u32));
        let b = Arc::new(tokio::sync::Mutex::new(0u32));
        let c = Arc::new(tokio::sync::Mutex::new(0u32));

        let aa = a.clone();
        let _sa = bus
            .subscribe(move |_e: &dyn Event| {
                let aa = aa.clone();
                async move {
                    *aa.lock().await += 1;
                    Ok(())
                }
            })
            .await;
        let bb = b.clone();
        let _sb = bus
            .subscribe(move |_e: &dyn Event| {
                let bb = bb.clone();
                async move {
                    *bb.lock().await += 1;
                    Ok(())
                }
            })
            .await;
        let cc = c.clone();
        let _sc = bus
            .subscribe_to("multi.kind".to_string(), move |_e: &dyn Event| {
                let cc = cc.clone();
                async move {
                    *cc.lock().await += 1;
                    Ok(())
                }
            })
            .await;

        let evt = Wave2Sample::new("multi.kind", "fanout");
        let ack = bus.publish(&evt).await.expect("publish ok");
        // two wildcard + one topic-specific = 3 deliveries
        assert_eq!(ack.delivered_to, 3);
        assert_eq!(*a.lock().await, 1);
        assert_eq!(*b.lock().await, 1);
        assert_eq!(*c.lock().await, 1);
        assert_eq!(bus.handler_count().await, 3);
    }

    #[test]
    fn version_helper_matches_cargo_pkg_version() {
        assert_eq!(version(), env!("CARGO_PKG_VERSION"));
        assert_eq!(version(), VERSION);
        assert!(!version().is_empty(), "version must not be empty");
    }

    #[test]
    fn name_helper_matches_cargo_pkg_name() {
        assert_eq!(name(), env!("CARGO_PKG_NAME"));
        assert_eq!(name(), NAME);
        assert_eq!(name(), "phenotype-bus");
    }
}
