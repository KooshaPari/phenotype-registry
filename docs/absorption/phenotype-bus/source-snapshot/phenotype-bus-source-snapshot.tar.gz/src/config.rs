//! Configuration for the phenotype-bus event bus.
//!
//! All configuration is driven by environment variables with sensible defaults,
//! so the bus works out of the box without any explicit configuration.
//!
//! # Environment Variables
//!
//! | Variable | Default | Description |
//! |---|---|---|
//! | `PHENOTYPE_BUS_LOG_LEVEL` | `info` | Default log level when `RUST_LOG` is unset |
//! | `PHENOTYPE_BUS_RETRY_MAX_ATTEMPTS` | `3` | Max delivery attempts per handler |
//! | `PHENOTYPE_BUS_RETRY_BACKOFF_MS` | `10` | Backoff between retries (milliseconds) |
//!
//! # Usage
//!
//! ```ignore
//! use phenotype_bus::Config;
//!
//! let cfg = Config::from_env();
//! let bus = phenotype_bus::events::InMemoryBus::with_retry(cfg.bus.retry_policy());
//! ```

use std::time::Duration;

/// Global bus configuration loaded from environment variables.
///
/// Create one with [`Config::from_env`] or [`Config::default`].
#[derive(Clone, Debug)]
pub struct Config {
    /// Observability settings.
    pub observability: ObservabilityConfig,
    /// Bus runtime settings.
    pub bus: BusConfig,
}

/// Observability configuration.
#[derive(Clone, Debug)]
pub struct ObservabilityConfig {
    /// Default log level when `RUST_LOG` is not set.
    ///
    /// Read from `PHENOTYPE_BUS_LOG_LEVEL` (default: `"info"`).
    pub default_log_level: String,
}

/// Bus runtime configuration.
#[derive(Clone, Debug)]
pub struct BusConfig {
    /// Maximum number of delivery attempts per handler.
    ///
    /// Read from `PHENOTYPE_BUS_RETRY_MAX_ATTEMPTS` (default: `3`).
    pub retry_max_attempts: usize,

    /// Backoff duration between retries in milliseconds.
    ///
    /// Read from `PHENOTYPE_BUS_RETRY_BACKOFF_MS` (default: `10`).
    pub retry_backoff_ms: u64,
}

impl Config {
    /// Load configuration from environment variables.
    ///
    /// Falls back to documented defaults for any unset variable.
    pub fn from_env() -> Self {
        Self {
            observability: ObservabilityConfig::from_env(),
            bus: BusConfig::from_env(),
        }
    }
}

impl Default for Config {
    fn default() -> Self {
        Self::from_env()
    }
}

impl ObservabilityConfig {
    /// Load observability config from environment variables.
    pub fn from_env() -> Self {
        Self {
            default_log_level: std::env::var("PHENOTYPE_BUS_LOG_LEVEL")
                .unwrap_or_else(|_| "info".to_string()),
        }
    }
}

impl Default for ObservabilityConfig {
    fn default() -> Self {
        Self::from_env()
    }
}

impl BusConfig {
    /// Load bus config from environment variables.
    ///
    /// Defaults are sourced from
    /// [`RetryPolicy::default`](crate::events::RetryPolicy::default) so the
    /// env-driven surface and the in-code default cannot drift.
    pub fn from_env() -> Self {
        let default_policy = crate::events::RetryPolicy::default();
        Self {
            retry_max_attempts: std::env::var("PHENOTYPE_BUS_RETRY_MAX_ATTEMPTS")
                .ok()
                .and_then(|v| v.parse().ok())
                .unwrap_or(default_policy.max_attempts),
            retry_backoff_ms: std::env::var("PHENOTYPE_BUS_RETRY_BACKOFF_MS")
                .ok()
                .and_then(|v| v.parse().ok())
                .unwrap_or(default_policy.backoff.as_millis() as u64),
        }
    }

    /// Build a [`RetryPolicy`](crate::events::RetryPolicy) from this configuration.
    pub fn retry_policy(&self) -> crate::events::RetryPolicy {
        crate::events::RetryPolicy {
            max_attempts: self.retry_max_attempts,
            backoff: Duration::from_millis(self.retry_backoff_ms),
        }
    }
}

impl Default for BusConfig {
    fn default() -> Self {
        Self::from_env()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Mutex;

    // Tests below mutate process-wide env vars. Serialize them so parallel
    // test threads don't observe each other's env state.
    static ENV_LOCK: Mutex<()> = Mutex::new(());

    #[test]
    fn from_env_uses_defaults_when_unset() {
        let _g = ENV_LOCK.lock().unwrap();
        // Unset any env vars that might interfere
        std::env::remove_var("PHENOTYPE_BUS_LOG_LEVEL");
        std::env::remove_var("PHENOTYPE_BUS_RETRY_MAX_ATTEMPTS");
        std::env::remove_var("PHENOTYPE_BUS_RETRY_BACKOFF_MS");

        let cfg = Config::from_env();
        assert_eq!(cfg.observability.default_log_level, "info");
        assert_eq!(cfg.bus.retry_max_attempts, 3);
        assert_eq!(cfg.bus.retry_backoff_ms, 10);
    }

    #[test]
    fn from_env_reads_environment() {
        let _g = ENV_LOCK.lock().unwrap();
        std::env::set_var("PHENOTYPE_BUS_LOG_LEVEL", "debug");
        std::env::set_var("PHENOTYPE_BUS_RETRY_MAX_ATTEMPTS", "5");
        std::env::set_var("PHENOTYPE_BUS_RETRY_BACKOFF_MS", "100");

        let cfg = Config::from_env();
        assert_eq!(cfg.observability.default_log_level, "debug");
        assert_eq!(cfg.bus.retry_max_attempts, 5);
        assert_eq!(cfg.bus.retry_backoff_ms, 100);

        // Clean up
        std::env::remove_var("PHENOTYPE_BUS_LOG_LEVEL");
        std::env::remove_var("PHENOTYPE_BUS_RETRY_MAX_ATTEMPTS");
        std::env::remove_var("PHENOTYPE_BUS_RETRY_BACKOFF_MS");
    }

    #[test]
    fn retry_policy_from_config() {
        let _g = ENV_LOCK.lock().unwrap();
        let cfg = BusConfig {
            retry_max_attempts: 7,
            retry_backoff_ms: 250,
        };

        let policy = cfg.retry_policy();
        assert_eq!(policy.max_attempts, 7);
        assert_eq!(policy.backoff, Duration::from_millis(250));
    }

    #[test]
    fn invalid_env_var_falls_back_to_default() {
        let _g = ENV_LOCK.lock().unwrap();
        std::env::set_var("PHENOTYPE_BUS_RETRY_MAX_ATTEMPTS", "not-a-number");
        std::env::set_var("PHENOTYPE_BUS_RETRY_BACKOFF_MS", "also-not");

        let cfg = BusConfig::from_env();
        assert_eq!(cfg.retry_max_attempts, 3);
        assert_eq!(cfg.retry_backoff_ms, 10);

        std::env::remove_var("PHENOTYPE_BUS_RETRY_MAX_ATTEMPTS");
        std::env::remove_var("PHENOTYPE_BUS_RETRY_BACKOFF_MS");
    }
}
