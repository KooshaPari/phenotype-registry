//! Tracing setup and span helpers for the event bus.

use tracing::Span;
use tracing_subscriber::EnvFilter;

use crate::config::ObservabilityConfig;

/// Initialize a global tracing subscriber driven by `RUST_LOG`.
///
/// When `RUST_LOG` is unset, falls back to
/// [`PHENOTYPE_BUS_LOG_LEVEL`](ObservabilityConfig::default_log_level)
/// environment variable, or `"info"` if that is also unset.
///
/// Idempotent: subsequent calls are no-ops, so tests and binaries can call
/// this freely without panicking on re-initialization.
pub fn init_tracing() {
    let default_level = ObservabilityConfig::from_env().default_log_level;
    let _ = tracing_subscriber::fmt()
        .with_env_filter(
            EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| EnvFilter::new(&default_level)),
        )
        .with_target(false)
        .try_init();
}

/// Build a span for a single event handling attempt.
///
/// Use this around a handler invocation so the bus can record `event_id`,
/// `kind`, and `source` automatically on every log line.
pub fn make_span(event_id: uuid::Uuid, kind: &str, source: &str) -> Span {
    tracing::info_span!(
        "bus.event",
        event_id = %event_id,
        kind = %kind,
        source = %source,
    )
}
