//! Event bus domain types.
//!
//! This module is the wave-2 libification of the original flat `lib.rs`
//! bus. It exposes a [`Event`] trait, a portable [`EventBus`] contract, an
//! [`InMemoryBus`] implementation, and a [`Subscription`] handle.

pub mod bus;
pub mod subscription;

pub use bus::{
    Ack, EventBus, Handler, HandlerError, IdempotentHandler, InMemoryBus, PublishError, RetryPolicy,
};
pub use subscription::Subscription;

use chrono::{DateTime, Utc};
use uuid::Uuid;

/// Core trait for everything that can be published on the bus.
///
/// Implementors get a stable [`Uuid`] for cross-repo correlation, a `kind`
/// string for routing, a `source` producer identifier, and a `ts` timestamp.
pub trait Event: Send + Sync + 'static {
    /// Stable event id. Default: a fresh v4 UUID.
    fn id(&self) -> Uuid {
        Uuid::new_v4()
    }

    /// Logical event kind (e.g. `"user.created"`). Used for topic routing.
    fn kind(&self) -> &str;

    /// Producer identifier (service, crate, or repo name).
    fn source(&self) -> &str;

    /// Event timestamp. Default: "now" in UTC.
    fn ts(&self) -> DateTime<Utc> {
        Utc::now()
    }
}

impl<T> Event for std::sync::Arc<T>
where
    T: Event + ?Sized,
{
    fn id(&self) -> Uuid {
        (**self).id()
    }
    fn kind(&self) -> &str {
        (**self).kind()
    }
    fn source(&self) -> &str {
        (**self).source()
    }
    fn ts(&self) -> DateTime<Utc> {
        (**self).ts()
    }
}

/// Convenience macro for implementing [`Event`] on a type.
///
/// ```
/// use phenotype_bus::impl_event;
/// use serde::Serialize;
///
/// #[derive(Serialize)]
/// struct UserCreated {
///     user_id: String,
/// }
///
/// impl_event!(UserCreated, kind = "user.created", source = "sidekick");
/// ```
#[macro_export]
macro_rules! impl_event {
    ($ty:ty, kind = $kind:expr, source = $source:expr) => {
        impl $crate::events::Event for $ty {
            fn kind(&self) -> &str {
                $kind
            }
            fn source(&self) -> &str {
                $source
            }
        }
    };
    ($ty:ty, $name:expr) => {
        impl $crate::events::Event for $ty {
            fn kind(&self) -> &str {
                $name
            }
            fn source(&self) -> &str {
                stringify!($ty)
            }
        }
    };
}
