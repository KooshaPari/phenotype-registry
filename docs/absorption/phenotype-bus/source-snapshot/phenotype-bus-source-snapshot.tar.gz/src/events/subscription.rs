//! Subscription handle returned by [`crate::events::EventBus::subscribe`].

use tokio::sync::oneshot;
use uuid::Uuid;

/// Handle for an active subscription.
///
/// Drop the subscription or call [`Subscription::cancel`] to stop the
/// background delivery task. The `topic` is recorded for diagnostics so
/// operators can tell which channel a cancelled subscription belonged to.
pub struct Subscription {
    /// Stable id of this subscription, distinct from the event id.
    pub id: Uuid,
    /// Topic the subscription is registered against.
    pub topic: String,
    /// One-shot cancel signal; `send` is called exactly once.
    pub cancel: Option<oneshot::Sender<()>>,
}

impl Subscription {
    /// Construct a new subscription handle.
    pub fn new(topic: impl Into<String>, cancel: oneshot::Sender<()>) -> Self {
        Self {
            id: Uuid::new_v4(),
            topic: topic.into(),
            cancel: Some(cancel),
        }
    }

    /// Cancel the subscription. Idempotent — safe to call multiple times.
    pub fn cancel(&mut self) {
        if let Some(tx) = self.cancel.take() {
            let _ = tx.send(());
        }
    }

    /// Whether this subscription is still active (cancel not yet sent).
    pub fn is_active(&self) -> bool {
        self.cancel.is_some()
    }
}

impl Drop for Subscription {
    fn drop(&mut self) {
        if let Some(tx) = self.cancel.take() {
            let _ = tx.send(());
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn cancel_signals_receiver() {
        let (tx, mut rx) = oneshot::channel();
        let mut sub = Subscription::new("topic", tx);
        sub.cancel();
        assert!(rx.try_recv().is_ok());
    }

    #[tokio::test]
    async fn drop_signals_receiver() {
        let (tx, mut rx) = oneshot::channel();
        {
            let _sub = Subscription::new("topic", tx);
        }
        assert!(rx.try_recv().is_ok());
    }

    #[test]
    fn is_active_reflects_cancel() {
        let (tx, _rx) = oneshot::channel();
        let sub = Subscription::new("topic", tx);
        assert!(sub.is_active());
        let (tx2, _rx2) = oneshot::channel();
        let mut sub2 = Subscription::new("topic", tx2);
        sub2.cancel();
        assert!(!sub2.is_active());
    }
}
