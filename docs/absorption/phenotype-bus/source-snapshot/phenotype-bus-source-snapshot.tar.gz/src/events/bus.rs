//! [`EventBus`] contract and the in-memory implementation.

use std::collections::{HashMap, HashSet};
use std::sync::Arc;
use std::time::Duration;

use async_trait::async_trait;
use chrono::{DateTime, Utc};
use thiserror::Error;
use tokio::sync::{oneshot, Mutex, RwLock};
use tracing::{debug, warn};
use uuid::Uuid;

use super::subscription::Subscription;
use super::Event;

/// Acknowledgement returned by [`EventBus::publish`].
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Ack {
    pub event_id: Uuid,
    pub kind: String,
    pub source: String,
    pub ts: DateTime<Utc>,
    /// Number of handlers the event was dispatched to.
    pub delivered_to: usize,
}

/// Errors raised by [`EventBus::publish`].
#[derive(Error, Debug)]
pub enum PublishError {
    #[error("bus is shutting down")]
    Shutdown,
    #[error("no handlers registered for kind {0}")]
    NoHandlers(String),
    #[error("handler exhausted retries after {attempts} attempts: {message}")]
    HandlerExhausted { attempts: usize, message: String },
    #[error("internal bus error: {0}")]
    Internal(String),
}

/// Errors raised by a single [`Handler::handle`] call.
#[derive(Error, Debug)]
pub enum HandlerError {
    #[error("handler failed: {0}")]
    Failed(String),
    #[error("handler transient error: {0}")]
    Transient(String),
}

/// Retry policy for at-least-once delivery.
#[derive(Clone, Copy, Debug)]
pub struct RetryPolicy {
    /// Total attempts including the first try. Must be >= 1.
    pub max_attempts: usize,
    /// Sleep between attempts.
    pub backoff: Duration,
}

impl Default for RetryPolicy {
    fn default() -> Self {
        Self {
            max_attempts: 3,
            backoff: Duration::from_millis(10),
        }
    }
}

/// Object-safe handler trait. The bus dispatches events to handlers.
#[async_trait]
pub trait Handler: Send + Sync + 'static {
    /// Process a single event. Returning `Ok(())` acks the delivery.
    async fn handle(&self, event: &dyn Event) -> Result<(), HandlerError>;
}

/// Blanket impl so plain async closures can be used as handlers.
#[async_trait]
impl<F, Fut> Handler for F
where
    F: Fn(&dyn Event) -> Fut + Send + Sync + 'static,
    Fut: std::future::Future<Output = Result<(), HandlerError>> + Send + 'static,
{
    async fn handle(&self, event: &dyn Event) -> Result<(), HandlerError> {
        (self)(event).await
    }
}

/// Wrapper that adds idempotency on top of any handler.
///
/// Tracks every event id handed to the inner handler. Re-deliveries of the
/// same id are short-circuited to `Ok(())` without re-invoking the inner
/// handler. This is the consumer-side of the at-least-once contract.
pub struct IdempotentHandler<H: Handler> {
    inner: H,
    seen: Mutex<HashSet<Uuid>>,
}

impl<H: Handler> IdempotentHandler<H> {
    /// Wrap `inner` in a deduping handler.
    pub fn new(inner: H) -> Self {
        Self {
            inner,
            seen: Mutex::new(HashSet::new()),
        }
    }

    /// Number of distinct event ids processed so far.
    pub async fn seen_count(&self) -> usize {
        self.seen.lock().await.len()
    }
}

#[async_trait]
impl<H: Handler> Handler for IdempotentHandler<H> {
    async fn handle(&self, event: &dyn Event) -> Result<(), HandlerError> {
        let id = event.id();
        {
            let mut seen = self.seen.lock().await;
            if !seen.insert(id) {
                debug!(%id, "idempotent skip");
                return Ok(());
            }
        }
        self.inner.handle(event).await
    }
}

/// Cross-repo pub/sub bus contract.
#[async_trait]
pub trait EventBus: Send + Sync + 'static {
    /// Publish an event. Returns an [`Ack`] on successful dispatch.
    async fn publish(&self, event: &dyn Event) -> Result<Ack, PublishError>;

    /// Subscribe a handler to every event published after registration.
    async fn subscribe<H: Handler>(&self, handler: H) -> Subscription;

    /// Subscribe a handler to a single topic (`event.kind()`).
    async fn subscribe_to<H: Handler>(&self, topic: String, handler: H) -> Subscription;

    /// Current number of registered handlers.
    async fn handler_count(&self) -> usize;
}

/// Per-handler bookkeeping: the boxed handler + its id.
struct HandlerSlot {
    id: Uuid,
    handler: Box<dyn Handler>,
}

/// In-memory [`EventBus`] with at-least-once delivery and topic routing.
pub struct InMemoryBus {
    /// Topic -> handlers registered for that topic.
    channels: Arc<RwLock<HashMap<String, Vec<HandlerSlot>>>>,
    retry: RetryPolicy,
}

impl InMemoryBus {
    /// Create a new bus with the default retry policy.
    pub fn new() -> Self {
        Self::with_retry(RetryPolicy::default())
    }

    /// Create a new bus with a custom retry policy.
    pub fn with_retry(retry: RetryPolicy) -> Self {
        Self {
            channels: Arc::new(RwLock::new(HashMap::new())),
            retry,
        }
    }

    /// Current retry policy.
    pub fn retry_policy(&self) -> RetryPolicy {
        self.retry
    }

    /// Register a handler under `topic` and return its id + cancel sender.
    async fn insert(
        &self,
        topic: String,
        handler: Box<dyn Handler>,
    ) -> (Uuid, oneshot::Sender<()>) {
        let id = Uuid::new_v4();
        let (tx, rx) = oneshot::channel();
        {
            let mut channels = self.channels.write().await;
            channels
                .entry(topic)
                .or_default()
                .push(HandlerSlot { id, handler });
        }
        // Spawn a watcher that removes the slot when cancelled.
        let channels = self.channels.clone();
        tokio::spawn(async move {
            let _ = rx.await;
            let mut channels = channels.write().await;
            for slots in channels.values_mut() {
                slots.retain(|s| s.id != id);
            }
        });
        (id, tx)
    }
}

impl Default for InMemoryBus {
    fn default() -> Self {
        Self::new()
    }
}

#[async_trait]
impl EventBus for InMemoryBus {
    async fn publish(&self, event: &dyn Event) -> Result<Ack, PublishError> {
        let kind = event.kind().to_string();
        let source = event.source().to_string();
        let event_id = event.id();
        let ts = event.ts();

        // Hold the read lock for the whole dispatch. Handlers run in-line;
        // this keeps the at-least-once retry loop simple and correct, and
        // guarantees a stable view of `channels` for the whole delivery.
        let channels = self.channels.read().await;

        // Collect matching handler ids under the lock, then dispatch in id
        // order. Wildcard `*` handlers always run; topic-specific handlers
        // run when their topic equals `event.kind()`.
        let mut ids: Vec<Uuid> = Vec::new();
        if let Some(slots) = channels.get("*") {
            for s in slots {
                ids.push(s.id);
            }
        }
        if kind != "*" {
            if let Some(slots) = channels.get(&kind) {
                for s in slots {
                    ids.push(s.id);
                }
            }
        }

        if ids.is_empty() {
            return Err(PublishError::NoHandlers(kind));
        }

        // Build a lookup so we can find the handler ref by id without
        // walking the whole map per id. We keep the borrow tied to the
        // `channels` lock guard, which lives until the end of this scope.
        let mut lookup: HashMap<Uuid, &dyn Handler> = HashMap::with_capacity(ids.len());
        for slots in channels.values() {
            for slot in slots {
                if ids.contains(&slot.id) && !lookup.contains_key(&slot.id) {
                    lookup.insert(slot.id, slot.handler.as_ref());
                }
            }
        }

        let mut delivered = 0usize;
        for id in &ids {
            if let Some(handler) = lookup.get(id) {
                deliver_with_retry(*handler, event, self.retry).await?;
                delivered += 1;
            }
        }

        Ok(Ack {
            event_id,
            kind,
            source,
            ts,
            delivered_to: delivered,
        })
    }

    async fn subscribe<H: Handler>(&self, handler: H) -> Subscription {
        let (id, cancel) = self.insert("*".to_string(), Box::new(handler)).await;
        Subscription {
            id,
            topic: "*".to_string(),
            cancel: Some(cancel),
        }
    }

    async fn subscribe_to<H: Handler>(&self, topic: String, handler: H) -> Subscription {
        let (id, cancel) = self.insert(topic.clone(), Box::new(handler)).await;
        Subscription {
            id,
            topic,
            cancel: Some(cancel),
        }
    }

    async fn handler_count(&self) -> usize {
        let channels = self.channels.read().await;
        channels.values().map(|v| v.len()).sum()
    }
}

async fn deliver_with_retry(
    handler: &dyn Handler,
    event: &dyn Event,
    policy: RetryPolicy,
) -> Result<(), PublishError> {
    let mut attempt = 0usize;
    loop {
        attempt += 1;
        match handler.handle(event).await {
            Ok(()) => return Ok(()),
            Err(e) if attempt >= policy.max_attempts => {
                warn!(attempts = attempt, error = %e, "handler exhausted retries");
                return Err(PublishError::HandlerExhausted {
                    attempts: attempt,
                    message: e.to_string(),
                });
            }
            Err(e) => {
                debug!(attempt, error = %e, "handler transient error, retrying");
                if !policy.backoff.is_zero() {
                    tokio::time::sleep(policy.backoff).await;
                }
            }
        }
    }
}
