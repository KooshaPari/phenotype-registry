# WORKTREE-POINTER ORPHAN — Sentinel

**Audit date**: 2026-07-15
**Audit source**: `.research-repos-gitification-2026-07-15.md` Section 4.3
**Action taken**: TARBALL_ORPHAN

## What happened

This directory was a **worktree pointer** (`.git` is a `gitdir:` gitfile, not a
real `.git/` directory) pointing at:

```
/Users/kooshapari/CodeProjects/poa-fresh/.git/worktrees/home-recovery-2026-07
```

That gitdir did not exist on disk at audit time. The pointer is **orphaned**:
the intended parent repo's worktree registration was removed but this physical
checkout was left behind.

**Intended parent repo**: `poa-fresh (does not exist)`
**Intended branch**: `home-recovery-2026-07 (implied)`
**Reason**: Parent repo (poa-fresh) does not exist anywhere on disk; worktree was orphaned.

## Current state of this dir (left in place — NOT deleted)

- Pointer file: `/Users/kooshapari/CodeProjects/Phenotype/repos/phenotype-org-audits-wtrees/home-recovery-2026-07/.git` (broken, see path above)
- Physical source size: `6.5M` (440 files)
- Dir was **NOT** removed — only tarballed and labeled.

## Where the tarball lives

- **Path**: `~/CodeProjects/Phenotype/repos/_phenofleet-decisions/worktree-orphans/poa-wtrees-home-recovery-2026-07.tar.zst`
- **Relative**: `_phenofleet-decisions/worktree-orphans/poa-wtrees-home-recovery-2026-07.tar.zst`
- **SHA256**: `73154d0d3feef49e830d6c18c746e2c2eb198ad60810d72da5cad48aa808b34a`
- **Compressed size**: 1.3 MB

## How to restore

```bash
# 1. Verify the tarball
sha256sum -c \
  ~/CodeProjects/Phenotype/repos/_phenofleet-decisions/worktree-orphans/SHA256SUMS.txt \
  | grep poa-wtrees-home-recovery-2026-07.tar.zst

# 2. Extract back into place (preserves pointer file for forensic reference)
mkdir -p <scratch-restore-dir>
tar --zstd -xf ~/CodeProjects/Phenotype/repos/_phenofleet-decisions/worktree-orphans/poa-wtrees-home-recovery-2026-07.tar.zst -C <scratch-restore-dir>

# 3. Optional: re-attach as a real worktree (requires restoring the parent repo)
#    git -C <parent-repo> worktree add <original-dir-path> <branch-name>
```

## See also

- `.research-repos-gitification-2026-07-15.md` — full audit
- `.subagent-3-worktree-pointer-audit-2026-07-15.json` — machine-readable record
- `.subagent-3-worktree-pointer-summary-2026-07-15.md` — narrative summary
- `_phenofleet-decisions/worktree-orphans/INDEX.md` — all orphans + restore commands
