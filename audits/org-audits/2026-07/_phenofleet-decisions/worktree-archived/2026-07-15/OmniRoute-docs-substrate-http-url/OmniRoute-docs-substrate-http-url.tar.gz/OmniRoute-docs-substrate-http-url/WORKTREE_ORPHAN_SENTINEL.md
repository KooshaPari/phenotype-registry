# WORKTREE-POINTER ORPHAN — Sentinel

**Audit date**: 2026-07-15
**Audit source**: `.research-repos-gitification-2026-07-15.md` Section 4.3
**Action taken**: TARBALL_ORPHAN

## What happened

This directory was a **worktree pointer** (`.git` is a `gitdir:` gitfile, not a
real `.git/` directory) pointing at:

```
/Users/kooshapari/CodeProjects/Phenotype/repos/OmniRoute/.git/worktrees/docs-substrate-http-url
```

That gitdir did not exist on disk at audit time. The pointer is **orphaned**:
the intended parent repo's worktree registration was removed but this physical
checkout was left behind.

**Intended parent repo**: `OmniRoute`
**Intended branch**: `docs-substrate-http-url (implied)`
**Reason**: Worktree entry was removed from parent repo; physical dir lingered.

## Current state of this dir (left in place — NOT deleted)

- Pointer file: `/Users/kooshapari/CodeProjects/Phenotype/repos/OmniRoute/.claude/worktrees/docs-substrate-http-url/.git` (broken, see path above)
- Physical source size: `9.3M` (552 files)
- Dir was **NOT** removed — only tarballed and labeled.

## Where the tarball lives

- **Path**: `~/CodeProjects/Phenotype/repos/_phenofleet-decisions/worktree-orphans/OmniRoute-docs-substrate-http-url.tar.zst`
- **Relative**: `_phenofleet-decisions/worktree-orphans/OmniRoute-docs-substrate-http-url.tar.zst`
- **SHA256**: `09bbcce115c5b30576168b2aa61a5a3104027ee056b9de25e70b5528b5232c68`
- **Compressed size**: 1.8 MB

## How to restore

```bash
# 1. Verify the tarball
sha256sum -c \
  ~/CodeProjects/Phenotype/repos/_phenofleet-decisions/worktree-orphans/SHA256SUMS.txt \
  | grep OmniRoute-docs-substrate-http-url.tar.zst

# 2. Extract back into place (preserves pointer file for forensic reference)
mkdir -p <scratch-restore-dir>
tar --zstd -xf ~/CodeProjects/Phenotype/repos/_phenofleet-decisions/worktree-orphans/OmniRoute-docs-substrate-http-url.tar.zst -C <scratch-restore-dir>

# 3. Optional: re-attach as a real worktree (requires restoring the parent repo)
#    git -C <parent-repo> worktree add <original-dir-path> <branch-name>
```

## See also

- `.research-repos-gitification-2026-07-15.md` — full audit
- `.subagent-3-worktree-pointer-audit-2026-07-15.json` — machine-readable record
- `.subagent-3-worktree-pointer-summary-2026-07-15.md` — narrative summary
- `_phenofleet-decisions/worktree-orphans/INDEX.md` — all orphans + restore commands
